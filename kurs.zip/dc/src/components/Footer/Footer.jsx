import React from 'react';
import { NavLink } from 'react-router-dom';

import './Footer.css';


const Footer = () => {
    return (
        <div>
            <footer className="site-footer">
                <div className="container">
                    <div className="row">
                    <div className="col-sm-12 col-md-6">
                        <h6>Коротко о нас</h6>
                        <p className="text-justify">
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione enim pariatur necessitatibus 
                            eligendi nesciunt minima itaque fugit inventore laudantium? Doloribus ipsa similique culpa iure asperiores. Vero dolorem 
                            mollitia repellat adipisci.
                        </p>
                </div>

                    <div className="col-xs-6 col-md-3">
                        <h6>Прямые ссылки</h6>
                        <ul className="footer-links">
                        <li><NavLink to="/">Главная</NavLink></li>
                        <li><NavLink to="/posts">Продукты</NavLink></li>
                        <li><NavLink to="/about">О нас</NavLink></li>
                        </ul>
                    </div>
                    </div>
                </div>
                
                <div className="container">
                <hr/>
                    <div className="row">
                    <div className="col-md-8 col-sm-6 col-xs-12">
                        <p className="copyright-text">Copyright &copy; 2022 Все права защищены правообладателем
                        </p>
                    </div>

                    <div className="col-md-4 col-sm-6 col-xs-12">
                        <ul className="social-icons">
                        <li><a className="vk" href="https://vk.com/yngdyn"></a></li>
                        <li><a className="dtf" href="https://dtf.ru/u/598446-anton-dudchenko"></a></li>
                        </ul>
                    </div>
                    </div>
                </div>
            </footer>
        </div>
    )
  }

export default Footer;