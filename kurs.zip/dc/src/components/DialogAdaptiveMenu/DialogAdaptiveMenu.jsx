import React ,{useState} from 'react';
import { NavLink } from 'react-router-dom';

import user  from '../../img/user.svg';

import './DialogAdaptiveMenu.css';


const DialogAdaptiveMenu = () => {
  const [open, setOpen] = useState(false)
  return (
    <div className='dialog-adpt-menu-wrapper'>
        <div className={user.Header}>
          <p className="menu cta" onClick={() => setOpen(true)} alt="cta">Menu</p>
        </div>
        
        <dialog open={open} className="dialog-adpt-menu">
          <div className="dialog-adpt-menu-link">
              <li><NavLink to="/" className='LinkTo'>Главная</NavLink></li>
              <li><NavLink to="/posts" className='LinkTo'>Продукты</NavLink></li>
              <li><NavLink to="/about" className='LinkTo'>О нас</NavLink></li>
          </div>
          <div className="dialog-adpt-menu-btn">
            <button onClick={() => setOpen(false)} className='dialog-menu-close'>close</button>
          </div>
        </dialog>
    </div>
  )
}

export { DialogAdaptiveMenu }