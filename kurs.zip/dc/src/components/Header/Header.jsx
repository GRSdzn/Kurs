import React from 'react';
import { NavLink } from 'react-router-dom';

import logo  from '../../img/logo.svg';

import { DialogAdaptiveMenu } from '../DialogAdaptiveMenu/DialogAdaptiveMenu';
import { DialogMenu } from '../DialogMenu/DialogMenu';
import './Header.css';


const Header = () => {

  return (
    <div className="wrapper">
      
        <header>
          <div className={logo.Header}>
            <NavLink to='/'><img className='logo' src={logo} alt="logo"/></NavLink>
          </div>
          <nav>
              <ul className="nav__links">
                  <li><NavLink to="/">Главная</NavLink></li>
                  <li><NavLink to="/posts">Продукты</NavLink></li>
                  <li><NavLink to="/about">О нас</NavLink></li>
              </ul>
          </nav>

          <DialogMenu />
          <DialogAdaptiveMenu />

        </header>

          <div id="mobile__menu" className="overlay">
            <div className="overlay__content">
              <li><NavLink to="/">Главная</NavLink></li>
              <li><NavLink to="/posts">Продукты</NavLink></li>
              <li><NavLink to="/about">О нас</NavLink></li>
            </div>
          </div>
        
    </div>
  )
}


export default Header;