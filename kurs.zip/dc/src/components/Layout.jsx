import { Outlet } from 'react-router-dom';
import Header from './Header/Header';
import Footer from '../components/Footer/Footer';

const Layout = () => {
  return (
    <>
    {/* <header className='header__container'>
      <NavLink to="/">Главная</NavLink>
      <NavLink to="/posts">Каталог</NavLink>
      <NavLink to="/about">О нас</NavLink>
    </header> */}

    <Header />
    

    <main className='container'>
    <Outlet />
    </main>
    <Footer />
    </>
  )
}


export {Layout}