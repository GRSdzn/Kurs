import React from 'react';
import './DialogMenu.css';
import user  from '../../img/user.svg';
import {useState} from 'react';

const DialogMenu = () => {
  const [open, setOpen] = useState(false)
  return (
    <div>          {/* Изображение пользователя с диалоговым окном */}
        <div className={user.Header}>
            <img className='user' onClick={() => setOpen(true)} src={user} alt="logo"/>
        </div>
        
        <dialog open={open} className="dialog-menu">
            <div>test text</div>
            <button onClick={() => setOpen(false)} className='dialog-menu-close'>Закрыть</button>
        </dialog>
    </div>
  )
}

export { DialogMenu }