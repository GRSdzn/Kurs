import { Link } from 'react-router-dom'

const NotFoundPage = () => {
    return (
        <div>
            Данная страница не найдена. Пожалуйста перейдите на  <Link to="/">Главную</Link>
        </div>
    )
}

export {NotFoundPage};
