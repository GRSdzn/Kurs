import React from 'react'; 
import './Homepage.css';
import { Carousel } from '../../components/Slider_main/Slider';

const Homepage = () => {
    return (
        <div className="bottom_head">  
            <Carousel>
                <div className="item item-1"></div>
                <div className="item item-2"></div>
                <div className="item item-3"></div>
            </Carousel>

            <div className="popular__catalog">
                <div className="popular__catalog-title">
                    <h1>Популярное</h1>
                </div>
            </div>
        </div>
    )
}

export {Homepage}