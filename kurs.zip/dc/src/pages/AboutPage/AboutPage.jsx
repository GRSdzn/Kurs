import { Outlet, Link } from 'react-router-dom';
import './AboutPage.css';

const About = () => {
    return (
        <div className='about-us-container'>
            <div className="about-us-title">
                <h1>О компании</h1>
            </div>
            <p className='about-us-description'>
                Популярные страницы Музыкальные инструменты и 
                звуковое оборудование в интернет-магазине DMSКлавишные инструменты 
                Струнно-клавишные музыкальные инструменты их видыАкустические системы 
                и акустикаГитары и бас-гитарыО музыкальных инструментах и музыкальном 
                оборудованииКак купитьЦифровые фортепиано и роялиСинтезаторыFENDER 
                MUSTANG I гитарный комбоусилитель, 20 ВтУдарные установки и барабаны
                Популярные бренды цифровых пианиноМикрофоны и радиосистемыАктивная 
                акустикаДуховые инструменты Becker BDP-82W цифровое пианино, цвет белый, 
                клавиатура 88 клавиш с молоточкамиFENDER CD-60CE DREADNOUGHT BLACK Доставка 
                и самовывозBecker BDP-92W цифровое пианино, цвет белый, клавиатура 
                88 клавишYAMAHA PSR-E473 синтезатор с автоаккомпанементом, 61кл/ 64 полиф/820 тембра/290 стилей
            </p>
            <div className="about-us-info-list-container">
                <div className="about-us-info-list-title-wrapper">
                    <h1 className="about-us-info-list-title-text">18+</h1>
                    <hr className='list-stroke-hr'/>
                    <p className="about-us-info-list-description">ЛЕТ ОПЫТА И СОВЕРШЕНСТВАНИЯ</p>
                </div>
                <div className="about-us-info-list-title-wrapper">
                    <h1 className="about-us-info-list-title-text">99+</h1>
                    <hr className='list-stroke-hr'/>
                    <p className="about-us-info-list-description">ПОСТОЯННО ПОПОЛНЯЕМЫХ ТОВАРОВ</p>
                </div>
                <div className="about-us-info-list-title-wrapper">
                    <h1 className="about-us-info-list-title-text">24ч</h1>
                    <hr className='list-stroke-hr'/>
                    <p className="about-us-info-list-description">ПОСТОЯННАЯ ПОДДДЕРЖКА</p>
                </div>
            </div>

            <div className="about-us-link-list">
                <ul>
                    <li><Link to="contacts">Our Contacts</Link></li>
                    <li><Link to="team">Our Team</Link></li>
                </ul>
            </div>

            <Outlet />
        </div>
    )
}

export {About}